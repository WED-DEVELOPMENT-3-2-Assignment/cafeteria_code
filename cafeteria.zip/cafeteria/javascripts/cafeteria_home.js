// Run everything after the DOM is ready
document.addEventListener("DOMContentLoaded", () => {

  /* --------------------------
     1️⃣ Display Current Date
  --------------------------- */
  const dateElement = document.getElementById("currentDate");
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  dateElement.textContent = now.toLocaleDateString("en-US", options);

  /* ----------------------------------------
     2️⃣ Simulate Total Sales Accumulation
  ----------------------------------------- */
  const salesDisplay = document.getElementById("totalSales");
  let totalSales = 0;

  // Simulate continuous sales growth (for demo purposes)
  setInterval(() => {
    const increment = Math.floor(Math.random() * 50) + 20; // between R20–R70
    totalSales += increment;
    salesDisplay.textContent = `R${totalSales.toFixed(2)}`;
  }, 4000); // updates every 4 seconds

  /* ----------------------------------------
     3️⃣ Populate Low Stock Table
  ----------------------------------------- */
  // Example dummy data (to replace with DB values later)
  const items = [
    { name: "Biscuit Pack", category: "Snacks", stock: 4 },
    { name: "Orange Juice", category: "Drinks", stock: 8 },
    { name: "Beef Pie", category: "Meals", stock: 2 }
  ];

  const threshold = 10;
  const lowStockTableBody = document.getElementById("lowStockTableBody");
  if (lowStockTableBody) {
    lowStockTableBody.innerHTML = ""; // Clear placeholder row

    items
      .filter(item => item.stock < threshold)
      .forEach(item => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${item.name}</td>
          <td>${item.category}</td>
          <td>${item.stock}</td>
        `;
        lowStockTableBody.appendChild(row);
      });

    // If no items are low in stock
    if (lowStockTableBody.innerHTML.trim() === "") {
      lowStockTableBody.innerHTML = `
        <tr><td colspan="3" style="text-align:center; color:#777;">
          All stocks are sufficient
        </td></tr>
      `;
    }
  }

});
