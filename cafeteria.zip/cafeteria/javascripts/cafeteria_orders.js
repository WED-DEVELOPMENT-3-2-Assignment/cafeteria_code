// Example order data (you'll later replace this with data from backend)
const orders = [
  {
    id: 101,
    email: "student01@vut.ac.za",
    contents: [
      { name: "Kota (Egg)", qty: 1 },
      { name: "Kota (Vienna)", qty: 1 },
      { name: "Coke", qty: 3 },
      { name: "Biscuits", qty: 4 }
    ],
    amount: 165.00,
    status: "In Progress"
  },
  {
    id: 102,
    email: "student02@vut.ac.za",
    contents: [
      { name: "Beef Pie", qty: 2 },
      { name: "Fanta Orange", qty: 2 }
    ],
    amount: 90.00,
    status: "Ready"
  }
];

// Populate table
const ordersTableBody = document.getElementById("ordersTableBody");
ordersTableBody.innerHTML = "";

orders.forEach(order => {
  const row = document.createElement("tr");

  // Format order contents as readable list
  const orderList = order.contents
    .map(item => `${item.qty} × ${item.name}`)
    .join("<br>");

  // Determine status button class
  let statusClass = "status-in-progress";
  if (order.status === "Ready") statusClass = "status-ready";
  if (order.status === "Completed") statusClass = "status-completed";

  row.innerHTML = `
    <td>#${order.id}</td>
    <td>${order.email}</td>
    <td class="order-content">${orderList}</td>
    <td>R${order.amount.toFixed(2)}</td>
    <td>${order.status}</td>
    <td>
      <button class="status-btn ${statusClass}" data-id="${order.id}">
        ${order.status}
      </button>
    </td>
  `;

  ordersTableBody.appendChild(row);
});

// Handle status updates
ordersTableBody.addEventListener("click", function(e) {
  if (e.target.classList.contains("status-btn")) {
    const button = e.target;
    const current = button.textContent;

    // Cycle through statuses
    let nextStatus = "";
    if (current === "In Progress") nextStatus = "Ready";
    else if (current === "Ready") nextStatus = "Completed";
    else nextStatus = "In Progress";

    // Update button and status cell
    button.textContent = nextStatus;
    button.className = `status-btn ${
      nextStatus === "Ready"
        ? "status-ready"
        : nextStatus === "Completed"
        ? "status-completed"
        : "status-in-progress"
    }`;

    // Update the status cell in the same row
    const row = button.closest("tr");
    row.cells[4].textContent = nextStatus;
  }
});
