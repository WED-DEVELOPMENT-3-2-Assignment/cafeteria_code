const form = document.getElementById("addMenuForm");
const tableBody = document.getElementById("menuTableBody");
const searchBar = document.getElementById("searchBar");

form.addEventListener("submit", function(e) {
  e.preventDefault();

  const name = document.getElementById("itemName").value;
  const category = document.getElementById("category").value;
  const price = document.getElementById("price").value;
  const stock = document.getElementById("stock").value || "-";
  const threshold = document.getElementById("threshold").value || "-";
  const imageInput = document.getElementById("image");

  let imageURL = "";
  if (imageInput.files && imageInput.files[0]) {
    imageURL = URL.createObjectURL(imageInput.files[0]);
  }

  // Check if stock is below threshold
  let stockStyle = "";
  if (stock !== "-" && threshold !== "-") {
    const stockVal = parseInt(stock);
    const thresVal = parseInt(threshold);
    if (!isNaN(stockVal) && !isNaN(thresVal) && stockVal < thresVal) {
      stockStyle = " style='color:red; font-weight:bold;'";
    }
  }

  // Create row
  const row = document.createElement("tr");
  row.innerHTML = `
    <td>—</td>
    <td>${imageURL ? `<img src="${imageURL}" alt="${name}" class="item-img">` : ""}${name}</td>
    <td>${category}</td>
    <td>R${parseFloat(price).toFixed(2)}</td>
    <td${stockStyle}>${stock}</td>
    <td><button class="btn-status">Available</button></td>
    <td><button class="btn-edit">Edit</button></td>
    <td><button class="btn-remove">Remove</button></td>
  `;

  tableBody.appendChild(row);
  form.reset();
});

// Toggle status button behavior
tableBody.addEventListener("click", function(e) {
  if (e.target.classList.contains("btn-status")) {
    const btn = e.target;
    if (btn.textContent === "Available") {
      btn.textContent = "Unavailable";
      btn.style.backgroundColor = "#b91c1c";
    } else {
      btn.textContent = "Available";
      btn.style.backgroundColor = "#2563eb";
    }
  }

  // Remove row
  if (e.target.classList.contains("btn-remove")) {
    e.target.closest("tr").remove();
  }
});

// Search filter by name
searchBar.addEventListener("input", function() {
  const filter = searchBar.value.toLowerCase();
  const rows = tableBody.getElementsByTagName("tr");
  Array.from(rows).forEach(row => {
    const nameCell = row.cells[1];
    if (!nameCell) return;
    const nameText = nameCell.textContent.toLowerCase();
    row.style.display = nameText.includes(filter) ? "" : "none";
  });
});
