// Simulated verification step
    document.getElementById('registerForm').addEventListener('submit', function(e) {
      e.preventDefault(); // stop normal form submit
      alert("A verification link has been sent to your student email.\nPlease verify your account before logging in.");
      window.location.href = "login.html"; // redirect to login after alert
    });